
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <section class="hk-sec-wrapper mt-50">
                    <h5 class="hk-sec-title mb-40">Add group name</h5>
                    <div class="row">
                        <div class="col-sm">
                            <form action="<?php echo e(route('add.group')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="g_name" placeholder="group name" aria-label="group name" aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="submit">Add</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
                <section class="hk-sec-wrapper">
                    <h5 class="hk-sec-title">Group Table</h5>
                    <div class="row">
                        <div class="col-sm">
                            <div class="table-wrap">
                                <div class="table-responsive">
                                    <table class="table mb-0">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Group Name</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php ($no=0); ?>
                                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php ($no++); ?>
                                            <tr>
                                                <td><?php echo e($no); ?></td>
                                                <td><?php echo e($group->group_name); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('view.category', $group->id)); ?>" class="mr-25" data-toggle="tooltip" data-original-title="Edit"> 
                                                        <i class="ion ion-md-add-circle-outline">Add Categories</i> 
                                                    </a>
                                                    <a href="<?php echo e(route('delete.group', $group->id)); ?>" data-toggle="tooltip" data-original-title="Close"> 
                                                        <i class="icon-trash txt-danger"></i> 
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hangout\Artic Design\Directory\directoryapp\resources\views/admin/category.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <!-- Preview Sec -->
    <section id="preview_sec" class="bg-white hk-landing-sec pb-30">
        <div class="container position-relative pt-50 ">
            <div class="row">
                <div class="col-lg-6 col-sm-6 text-left">
                    <span>Find Lawyers by</span>
                    <h1 class="font-48" style="color: black;">PRACTICE AREA</h1>
                </div>
                <div class="col-lg-6 col-sm-6 mt-30">
                    <form>
                        <div class="input-group d-inline-flex">
                            <input class="form-control" type="search" placeholder="Search" aria-label="Search">
                            <div class="input-group-append">
                                <button class="btn btn-grey" type="submit">Search</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- /Preview Sec -->
    <!-- Utilities Sec -->
    <section class="bg-white pb-35">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $dirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-sm-6 mb-45">
                        <h5 class="mb-20" style="color: black;">
                            <span class="d-flex align-items-center">
                                <i class="glyphicon glyphicon-th-list mr-15"></i>
                                <?php echo e($dir[0]->group_name); ?>

                            </span>
                        </h5>
                        <?php for($i=0; $i<count($dir);$i++): ?>
                            <a href="<?php echo e(route('detail', $dir[$i]->id)); ?>"><p><?php echo e($dir[$i]->ctg_name); ?></p></a>
                        <?php endfor; ?>
                    </div>                            
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- /Utilities Sec -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hangout\Artic Design\Directory\directoryapp\resources\views/welcome.blade.php ENDPATH**/ ?>
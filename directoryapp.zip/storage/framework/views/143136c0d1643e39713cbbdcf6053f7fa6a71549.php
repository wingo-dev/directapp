
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-xl-12">
            <section class="hk-sec-wrapper mt-50">
                <h5 class="hk-sec-title mb-40">Add Category name</h5>
                <div class="row">
                    <div class="col-sm">
                        <form action="<?php echo e(route('add.category')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <div class="input-group">
                                    <input type="hidden" name="g_id" value="<?php echo e($group_id); ?>">
                                    <input type="text" class="form-control" name="ctg_name" placeholder="category name" aria-label="category name" aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="submit">Add</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
            
            <section class="hk-sec-wrapper">
                <h5 class="hk-sec-title">Category Lists</h5>
                <div class="row">
                    <div class="col-sm">
                        <div class="table-wrap">
                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Category Name</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php ($no=0); ?>
                                        <?php $__currentLoopData = $ctgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php ($no++); ?>
                                        <tr>
                                            <td><?php echo e($no); ?></td>
                                            <td><?php echo e($ctg->ctg_name); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('delete.category', $ctg->id)); ?>" data-toggle="tooltip" data-original-title="Close"> 
                                                    <i class="icon-trash txt-danger"></i> 
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hangout\Artic Design\Directory\directoryapp\resources\views/admin/add_category.blade.php ENDPATH**/ ?>
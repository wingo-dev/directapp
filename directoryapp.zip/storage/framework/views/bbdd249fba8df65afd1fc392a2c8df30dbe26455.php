
<?php $__env->startSection('conetent'); ?>
<h1>pending listings here.</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hangout\Artic Design\Directory\directoryapp\resources\views/admin/pending_listings.blade.php ENDPATH**/ ?>
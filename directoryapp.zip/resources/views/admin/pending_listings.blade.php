@extends('layouts.adminlayout')
@section('conetent')
<h1>pending listings here.</h1>
@endsection